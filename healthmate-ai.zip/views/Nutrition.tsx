
import React, { useState } from 'react';
import { getNutritionSuggestions } from '../services/geminiService';

const Nutrition: React.FC = () => {
  const [mealType, setMealType] = useState('Lunch');
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchMeals = async () => {
    setLoading(true);
    try {
      const data = await getNutritionSuggestions(mealType);
      setSuggestions(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-6 pb-32">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center">
          <span className="material-icons-round">restaurant</span>
        </div>
        <div>
          <h2 className="text-xl font-bold text-gray-900">Campus Eats</h2>
          <p className="text-sm text-gray-500">Smart cafeteria navigator</p>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
        {['Breakfast', 'Lunch', 'Dinner', 'Post-Gym Snack'].map((m) => (
          <button
            key={m}
            onClick={() => { setMealType(m); setSuggestions([]); }}
            className={`px-6 py-2.5 rounded-2xl text-sm font-bold whitespace-nowrap transition-all border-2 ${
              mealType === m ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-gray-100 text-gray-400'
            }`}
          >
            {m}
          </button>
        ))}
      </div>

      <button 
        onClick={fetchMeals}
        disabled={loading}
        className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-100 hover:bg-emerald-700 disabled:opacity-50 transition-all"
      >
        {loading ? <span className="animate-spin material-icons-round">sync</span> : 'Find Healthy Options'}
      </button>

      <div className="space-y-4">
        {suggestions.map((meal, idx) => (
          <div 
            key={idx} 
            className="bg-white p-5 rounded-[2rem] shadow-sm border border-gray-100 animate-in fade-in slide-in-from-bottom-4"
            style={{ animationDelay: `${idx * 150}ms` }}
          >
            <div className="flex justify-between items-start mb-2">
              <h4 className="font-bold text-gray-900">{meal.name}</h4>
              <span className="text-[10px] font-bold text-emerald-600 px-2 py-1 bg-emerald-50 rounded-lg uppercase">{meal.location}</span>
            </div>
            <p className="text-xs text-gray-500 leading-relaxed mb-4">{meal.benefits}</p>
            <div className="flex gap-2">
               <div className="px-2 py-1 rounded bg-gray-50 text-[9px] font-bold text-gray-400">High Protein</div>
               <div className="px-2 py-1 rounded bg-gray-50 text-[9px] font-bold text-gray-400">Fiber Rich</div>
            </div>
          </div>
        ))}

        {!loading && suggestions.length === 0 && (
          <div className="text-center py-20 opacity-40">
            <span className="material-icons-round text-5xl mb-2">set_meal</span>
            <p className="text-sm">Select a meal category to see AI suggestions</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Nutrition;
