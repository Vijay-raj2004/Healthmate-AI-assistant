
import React, { useState } from 'react';
import { analyzeStress } from '../services/geminiService';
import { StressAnalysis } from '../types';

const CheckIn: React.FC = () => {
  const [mood, setMood] = useState(3);
  const [sleep, setSleep] = useState(7);
  const [notes, setNotes] = useState('');
  const [analysis, setAnalysis] = useState<StressAnalysis | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    setLoading(true);
    try {
      const result = await analyzeStress({ mood, sleep, notes });
      setAnalysis({
        ...result,
        timestamp: new Date().toLocaleTimeString()
      });
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-6 pb-32">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center">
          <span className="material-icons-round">edit_note</span>
        </div>
        <div>
          <h2 className="text-xl font-bold text-gray-900">How are you?</h2>
          <p className="text-sm text-gray-500">Log your state for AI insights</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-gray-100 space-y-8">
        <div>
          <label className="block text-sm font-bold text-gray-700 mb-6">Current Mood</label>
          <div className="flex justify-between items-center">
            {[1, 2, 3, 4, 5].map((m) => (
              <button
                key={m}
                onClick={() => setMood(m)}
                className={`w-12 h-12 rounded-2xl text-2xl transition-all ${
                  mood === m ? 'bg-indigo-600 scale-125 shadow-lg shadow-indigo-200' : 'bg-gray-50'
                }`}
              >
                {['😫', '😔', '😐', '🙂', '🤩'][m - 1]}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-4">Hours of Sleep</label>
          <input 
            type="range" min="3" max="12" step="0.5"
            value={sleep}
            onChange={(e) => setSleep(parseFloat(e.target.value))}
            className="w-full accent-indigo-600"
          />
          <div className="flex justify-between mt-2 text-xs font-bold text-gray-400">
            <span>3H</span>
            <span className="text-indigo-600 text-sm">{sleep} Hours</span>
            <span>12H</span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-2">Feeling stressed? (Optional notes)</label>
          <textarea 
            placeholder="I have three midterms this week and I'm feeling a bit overwhelmed..."
            className="w-full p-4 bg-gray-50 rounded-2xl border-transparent focus:ring-2 focus:ring-indigo-500 outline-none h-32 text-sm"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>

        <button 
          onClick={handleAnalyze}
          disabled={loading}
          className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 disabled:opacity-50 transition-all"
        >
          {loading ? (
            <span className="animate-spin material-icons-round">sync</span>
          ) : (
             <><span className="material-icons-round">auto_awesome</span> Analyze Stress</>
          )}
        </button>
      </div>

      {analysis && (
        <div className="bg-emerald-50 p-6 rounded-[2.5rem] border border-emerald-100 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="flex items-center gap-2 mb-3">
             <span className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider ${
               analysis.level === 'High' ? 'bg-red-100 text-red-600' : 
               analysis.level === 'Moderate' ? 'bg-orange-100 text-orange-600' : 
               'bg-emerald-100 text-emerald-600'
             }`}>
               Stress: {analysis.level}
             </span>
             <span className="text-[10px] text-gray-400">{analysis.timestamp}</span>
          </div>
          <p className="text-gray-800 text-sm leading-relaxed font-medium">
            <span className="block mb-2 text-emerald-800 font-bold">AI Recommendation:</span>
            {analysis.recommendation}
          </p>
        </div>
      )}
    </div>
  );
};

export default CheckIn;
