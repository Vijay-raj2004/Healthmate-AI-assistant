
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

const data = [
  { day: 'Mon', stress: 45, energy: 65 },
  { day: 'Tue', stress: 52, energy: 60 },
  { day: 'Wed', stress: 78, energy: 40 },
  { day: 'Thu', stress: 65, energy: 55 },
  { day: 'Fri', stress: 40, energy: 80 },
  { day: 'Sat', stress: 30, energy: 90 },
  { day: 'Sun', stress: 25, energy: 85 },
];

const AdminDashboard: React.FC = () => {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-900">Campus Trends</h2>
        <span className="px-3 py-1 bg-indigo-100 text-indigo-600 rounded-full text-[10px] font-bold">LIVE FEED</span>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 bg-white rounded-3xl border border-gray-100 shadow-sm">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Avg Stress</p>
          <p className="text-2xl font-bold text-red-500">62%</p>
          <p className="text-[10px] text-red-400 mt-1">+12% vs last week</p>
        </div>
        <div className="p-4 bg-white rounded-3xl border border-gray-100 shadow-sm">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Students Logged</p>
          <p className="text-2xl font-bold text-indigo-600">2.4k</p>
          <p className="text-[10px] text-indigo-400 mt-1">Active users</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-sm">
        <h3 className="text-sm font-bold text-gray-700 mb-6">Weekly Stress Distribution</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8'}} />
              <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8'}} />
              <Tooltip 
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                itemStyle={{ fontSize: '12px', fontWeight: 'bold' }}
              />
              <Bar dataKey="stress" fill="#6366f1" radius={[10, 10, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-sm">
        <h3 className="text-sm font-bold text-gray-700 mb-2">Anonymized Alerts</h3>
        <div className="space-y-3">
          {[
            { tag: 'High Stress Cluster', loc: 'South Dorms', icon: 'warning' },
            { tag: 'Low Sleep Average', loc: 'Engineering School', icon: 'bedtime' }
          ].map((alert, i) => (
            <div key={i} className="flex items-center gap-3 p-3 bg-gray-50 rounded-2xl">
              <span className="material-icons-round text-orange-500">{alert.icon}</span>
              <div>
                <p className="text-xs font-bold text-gray-800">{alert.tag}</p>
                <p className="text-[10px] text-gray-400">{alert.loc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
