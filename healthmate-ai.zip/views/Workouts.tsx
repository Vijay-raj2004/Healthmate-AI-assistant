
import React, { useState } from 'react';
import { getWorkoutSuggestions } from '../services/geminiService';

const Workouts: React.FC = () => {
  const [energy, setEnergy] = useState('Moderate');
  const [time, setTime] = useState(20);
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState<any>(null);

  const fetchWorkout = async () => {
    setLoading(true);
    try {
      const data = await getWorkoutSuggestions(energy, time);
      setPlan(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-6 pb-32">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-2xl flex items-center justify-center">
          <span className="material-icons-round">fitness_center</span>
        </div>
        <div>
          <h2 className="text-xl font-bold text-gray-900">Smart Fitness</h2>
          <p className="text-sm text-gray-500">Personalized routine generator</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-[2.5rem] shadow-sm space-y-6">
        <div>
          <label className="block text-sm font-bold text-gray-700 mb-4 text-center">Energy Level</label>
          <div className="flex bg-gray-50 p-1.5 rounded-2xl">
            {['Low', 'Moderate', 'High'].map((lvl) => (
              <button
                key={lvl}
                onClick={() => setEnergy(lvl)}
                className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all ${
                  energy === lvl ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-400'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-4 text-center">Time Available: <span className="text-indigo-600">{time}m</span></label>
          <div className="flex justify-between items-center gap-2">
            {[10, 20, 30, 45].map(t => (
              <button 
                key={t}
                onClick={() => setTime(t)}
                className={`w-12 h-12 rounded-xl border-2 flex items-center justify-center font-bold text-sm ${
                  time === t ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-gray-100 text-gray-400'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        <button 
          onClick={fetchWorkout}
          disabled={loading}
          className="w-full py-4 bg-orange-500 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-orange-600 disabled:opacity-50 transition-all"
        >
          {loading ? <span className="animate-spin material-icons-round">sync</span> : 'Generate Routine'}
        </button>
      </div>

      {plan && (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="bg-white p-6 rounded-[2.5rem] border border-gray-100">
            <h3 className="text-lg font-bold text-gray-900 mb-4">{plan.title}</h3>
            <ul className="space-y-3">
              {plan.exercises.map((ex: string, i: number) => (
                <li key={i} className="flex items-center gap-3 text-sm text-gray-700">
                  <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-600 text-[10px] flex items-center justify-center font-bold">{i+1}</div>
                  {ex}
                </li>
              ))}
            </ul>
            <div className="mt-6 pt-6 border-t border-gray-100">
              <p className="text-xs font-bold text-indigo-600 uppercase mb-2">Stretch Routine</p>
              <p className="text-sm text-gray-600 leading-relaxed italic">"{plan.stretch}"</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Workouts;
