
import React from 'react';

const Emergency: React.FC = () => {
  return (
    <div className="p-6 space-y-8 animate-in fade-in zoom-in duration-300">
      <div className="text-center py-10">
        <div className="w-24 h-24 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <span className="material-icons-round text-6xl">sos</span>
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Emergency Support</h2>
        <p className="text-gray-500 max-w-[250px] mx-auto text-sm">Help is always available. Choose an option below to connect with professional care.</p>
      </div>

      <div className="space-y-4">
        <button className="w-full p-6 bg-red-600 text-white rounded-[2.5rem] flex items-center gap-4 shadow-xl shadow-red-100 hover:bg-red-700 active:scale-[0.98] transition-all">
          <span className="material-icons-round text-3xl">call</span>
          <div className="text-left">
            <p className="font-bold">Campus Crisis Line</p>
            <p className="text-xs opacity-80">Available 24/7 for students</p>
          </div>
        </button>

        <button className="w-full p-6 bg-white border-2 border-red-100 text-red-600 rounded-[2.5rem] flex items-center gap-4 hover:bg-red-50 active:scale-[0.98] transition-all">
          <span className="material-icons-round text-3xl">message</span>
          <div className="text-left">
            <p className="font-bold">Crisis Text Line</p>
            <p className="text-xs text-gray-500">Text "HOME" to 741741</p>
          </div>
        </button>

        <div className="p-6 bg-gray-50 rounded-[2.5rem] space-y-4">
          <h4 className="font-bold text-gray-700 text-sm">Trusted Contacts</h4>
          <div className="flex items-center justify-between p-3 bg-white rounded-2xl">
            <div className="flex items-center gap-3">
               <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold">M</div>
               <div>
                  <p className="text-xs font-bold">Mom</p>
                  <p className="text-[10px] text-gray-400">+1 (555) 0123</p>
               </div>
            </div>
            <span className="material-icons-round text-gray-300">call</span>
          </div>
          <div className="flex items-center justify-between p-3 bg-white rounded-2xl">
            <div className="flex items-center gap-3">
               <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold">P</div>
               <div>
                  <p className="text-xs font-bold">Prof. Miller (Advisor)</p>
                  <p className="text-[10px] text-gray-400">+1 (555) 0456</p>
               </div>
            </div>
            <span className="material-icons-round text-gray-300">call</span>
          </div>
        </div>
      </div>

      <div className="text-center p-4">
        <p className="text-[10px] text-gray-400 font-medium">If you are in immediate danger, please dial 911 or your local emergency services.</p>
      </div>
    </div>
  );
};

export default Emergency;
