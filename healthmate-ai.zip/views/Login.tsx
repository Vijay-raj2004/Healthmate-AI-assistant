
import React, { useState } from 'react';
import { UserRole, User } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [role, setRole] = useState<UserRole>('student');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin({
      id: '1',
      name: role === 'admin' ? 'Coordinator Sarah' : 'Alex Johnson',
      email: `${role}@university.edu`,
      role
    });
  };

  return (
    <div className="mobile-frame min-h-screen bg-white flex flex-col items-center justify-center p-8">
      <div className="mb-12 text-center">
        <div className="w-20 h-20 bg-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-indigo-200">
          <span className="material-icons-round text-white text-4xl">health_and_safety</span>
        </div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">HealthMate AI</h1>
        <p className="text-gray-500">Your companion for a balanced campus life</p>
      </div>

      <form onSubmit={handleLogin} className="w-full space-y-6">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
          <input 
            type="email" 
            placeholder="alex@university.edu"
            className="w-full px-5 py-4 bg-gray-50 border-transparent rounded-2xl focus:bg-white focus:ring-2 focus:ring-indigo-500 transition-all outline-none"
            required
          />
        </div>
        
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Login as</label>
          <div className="grid grid-cols-3 gap-3">
            {(['student', 'staff', 'admin'] as UserRole[]).map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setRole(r)}
                className={`py-3 rounded-xl text-sm font-medium border-2 transition-all ${
                  role === r ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : 'border-gray-100 bg-white text-gray-500 hover:border-gray-200'
                }`}
              >
                {r.charAt(0).toUpperCase() + r.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <button 
          type="submit"
          className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg shadow-lg shadow-indigo-100 hover:bg-indigo-700 active:scale-[0.98] transition-all"
        >
          Get Started
        </button>
      </form>

      <p className="mt-8 text-sm text-gray-400">
        By continuing, you agree to our <span className="text-indigo-600 font-medium">Privacy Policy</span>
      </p>
    </div>
  );
};

export default Login;
