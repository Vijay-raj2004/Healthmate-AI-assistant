
import React from 'react';
import { DailyLog } from '../types';

const Dashboard: React.FC<{ logs: DailyLog[] }> = ({ logs }) => {
  const currentLog = logs[logs.length - 1];

  const StatCard = ({ icon, color, label, value, unit, bg }: any) => (
    <div className={`p-4 rounded-3xl ${bg} flex flex-col gap-3 h-full`}>
      <div className={`w-10 h-10 rounded-2xl ${color} flex items-center justify-center text-white`}>
        <span className="material-icons-round">{icon}</span>
      </div>
      <div>
        <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">{label}</p>
        <p className="text-xl font-bold text-gray-900">{value}<span className="text-sm font-normal text-gray-400 ml-1">{unit}</span></p>
      </div>
    </div>
  );

  const getMoodEmoji = (mood: number) => {
    const emojis = ['😫', '😔', '😐', '🙂', '🤩'];
    return emojis[mood - 1] || '😐';
  };

  return (
    <div className="p-6 space-y-6">
      <div className="bg-gradient-to-br from-indigo-600 to-violet-700 p-6 rounded-[2.5rem] text-white shadow-xl shadow-indigo-100 relative overflow-hidden">
        <div className="relative z-10">
          <h2 className="text-lg font-medium opacity-90">Good morning, Alex!</h2>
          <p className="text-2xl font-bold mt-1">Ready for your daily goals?</p>
          <div className="mt-6 flex items-center gap-4">
            <div className="bg-white/20 px-4 py-2 rounded-2xl backdrop-blur-sm">
              <p className="text-[10px] uppercase font-bold opacity-70">Mood Streak</p>
              <p className="text-lg font-bold">5 Days</p>
            </div>
            <div className="bg-white/20 px-4 py-2 rounded-2xl backdrop-blur-sm">
              <p className="text-[10px] uppercase font-bold opacity-70">Health Score</p>
              <p className="text-lg font-bold">84/100</p>
            </div>
          </div>
        </div>
        <span className="material-icons-round absolute -right-4 -bottom-4 text-white/10 text-[120px]">bubble_chart</span>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <StatCard 
          icon="bedtime" 
          color="bg-blue-500" 
          bg="bg-blue-50"
          label="Sleep" 
          value={currentLog.sleep} 
          unit="hrs" 
        />
        <StatCard 
          icon="water_drop" 
          color="bg-cyan-500" 
          bg="bg-cyan-50"
          label="Hydration" 
          value={currentLog.water} 
          unit="glasses" 
        />
        <StatCard 
          icon="directions_run" 
          color="bg-orange-500" 
          bg="bg-orange-50"
          label="Activity" 
          value={currentLog.activity} 
          unit="mins" 
        />
        <StatCard 
          icon="mood" 
          color="bg-pink-500" 
          bg="bg-pink-50"
          label="Mood" 
          value={getMoodEmoji(currentLog.mood)} 
          unit="" 
        />
      </div>

      <div className="bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-sm">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-bold text-gray-800">Recent Wellness Tip</h3>
          <span className="material-icons-round text-indigo-600">lightbulb</span>
        </div>
        <p className="text-gray-600 text-sm leading-relaxed">
          Studies show that students who drink at least 8 glasses of water daily have 15% better focus during afternoon lectures.
        </p>
      </div>
    </div>
  );
};

export default Dashboard;
