
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeStress = async (data: { mood: number, sleep: number, notes: string }) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this college student's stress levels: Mood (1-5): ${data.mood}, Sleep: ${data.sleep}hrs. Student says: "${data.notes}". Provide a structured response with a stress level (Low/Moderate/High) and a specific relaxation technique.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          level: { type: Type.STRING },
          recommendation: { type: Type.STRING }
        },
        required: ["level", "recommendation"]
      }
    }
  });

  return JSON.parse(response.text || '{}');
};

export const getNutritionSuggestions = async (mealType: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Suggest 3 healthy meal options for a college student for ${mealType} typically available in campus cafeterias. Focus on balanced nutrition (protein, greens, slow carbs).`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            benefits: { type: Type.STRING },
            location: { type: Type.STRING }
          }
        }
      }
    }
  });
  return JSON.parse(response.text || '[]');
};

export const getWorkoutSuggestions = async (energyLevel: string, timeAvailable: number) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Give a quick workout plan for a college student with ${energyLevel} energy and ${timeAvailable} minutes available. Include 3 exercises and a stretch.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          exercises: { type: Type.ARRAY, items: { type: Type.STRING } },
          stretch: { type: Type.STRING }
        }
      }
    }
  });
  return JSON.parse(response.text || '{}');
};
