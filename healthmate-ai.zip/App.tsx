
import React, { useState } from 'react';
import { View, User, DailyLog } from './types';
import Layout from './components/Layout';
import Login from './views/Login';
import Dashboard from './views/Dashboard';
import CheckIn from './views/CheckIn';
import Workouts from './views/Workouts';
import Nutrition from './views/Nutrition';
import Chat from './views/Chat';
import Emergency from './views/Emergency';
import AdminDashboard from './views/AdminDashboard';

const MOCK_LOGS: DailyLog[] = [
  { mood: 4, sleep: 7.5, water: 6, activity: 45, date: '2023-10-20' },
  { mood: 3, sleep: 6.0, water: 4, activity: 20, date: '2023-10-21' },
];

const App: React.FC = () => {
  const [currentView, setView] = useState<View>(View.LOGIN);
  const [user, setUser] = useState<User | null>(null);
  const [logs, setLogs] = useState<DailyLog[]>(MOCK_LOGS);

  const handleLogin = (u: User) => {
    setUser(u);
    setView(View.DASHBOARD);
  };

  const renderContent = () => {
    switch (currentView) {
      case View.LOGIN:
        return <Login onLogin={handleLogin} />;
      case View.DASHBOARD:
        return <Dashboard logs={logs} />;
      case View.CHECKIN:
        return <CheckIn />;
      case View.WORKOUTS:
        return <Workouts />;
      case View.NUTRITION:
        return <Nutrition />;
      case View.CHAT:
        return <Chat />;
      case View.EMERGENCY:
        return <Emergency />;
      case View.ADMIN:
        return <AdminDashboard />;
      default:
        return <Dashboard logs={logs} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center font-sans antialiased">
      {/* Desktop Wrapper to show mobile frame */}
      <div className="w-full md:w-auto h-screen md:h-auto">
        <Layout currentView={currentView} setView={setView} user={user}>
          {renderContent()}
        </Layout>
      </div>
    </div>
  );
};

export default App;
