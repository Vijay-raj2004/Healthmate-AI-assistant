
import React from 'react';
import { View, User } from '../types';

interface LayoutProps {
  currentView: View;
  setView: (view: View) => void;
  user: User | null;
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ currentView, setView, user, children }) => {
  const navItems = [
    { view: View.DASHBOARD, icon: 'dashboard', label: 'Home' },
    { view: View.CHECKIN, icon: 'favorite', label: 'Check-in' },
    { view: View.WORKOUTS, icon: 'fitness_center', label: 'Fit' },
    { view: View.NUTRITION, icon: 'restaurant', label: 'Eat' },
    { view: View.CHAT, icon: 'chat', label: 'Chat' },
  ];

  if (currentView === View.LOGIN) return <>{children}</>;

  return (
    <div className="mobile-frame flex flex-col h-screen relative overflow-hidden">
      {/* Top Header */}
      <header className="px-6 py-4 flex items-center justify-between bg-white border-b border-gray-100 z-10 shrink-0">
        <div>
          <h1 className="text-xl font-bold text-indigo-600">HealthMate AI</h1>
          <p className="text-xs text-gray-500">Welcome, {user?.name}</p>
        </div>
        <div className="flex gap-3">
           {user?.role === 'admin' && (
             <button 
              onClick={() => setView(View.ADMIN)}
              className="p-2 rounded-full bg-indigo-50 text-indigo-600"
            >
              <span className="material-icons-round">analytics</span>
            </button>
           )}
          <button 
            onClick={() => setView(View.EMERGENCY)}
            className="p-2 rounded-full bg-red-50 text-red-600"
          >
            <span className="material-icons-round">sos</span>
          </button>
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-y-auto pb-24 bg-slate-50">
        {children}
      </main>

      {/* Bottom Nav */}
      <nav className="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-6 py-3 flex justify-between items-center z-10 shrink-0">
        {navItems.map((item) => (
          <button
            key={item.view}
            onClick={() => setView(item.view)}
            className={`flex flex-col items-center gap-1 transition-all ${
              currentView === item.view ? 'text-indigo-600 scale-110' : 'text-gray-400'
            }`}
          >
            <span className="material-icons-round text-2xl">{item.icon}</span>
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};

export default Layout;
