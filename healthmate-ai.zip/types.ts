
export type UserRole = 'student' | 'staff' | 'admin';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  email: string;
}

export interface DailyLog {
  mood: number; // 1-5
  sleep: number; // hours
  water: number; // glasses
  activity: number; // minutes
  date: string;
}

export interface StressAnalysis {
  level: 'Low' | 'Moderate' | 'High';
  recommendation: string;
  timestamp: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

export enum View {
  LOGIN = 'LOGIN',
  DASHBOARD = 'DASHBOARD',
  CHECKIN = 'CHECKIN',
  WORKOUTS = 'WORKOUTS',
  NUTRITION = 'NUTRITION',
  CHAT = 'CHAT',
  EMERGENCY = 'EMERGENCY',
  ADMIN = 'ADMIN'
}
